#!/usr/bin/env php
<?php

// Include database initialization or connection code
include 'database.php';

function ip_visitor_country()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $country  = "Unknown";

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://www.geoplugin.net/json.gp?ip=".$ip);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    $ip_data_in = curl_exec($ch);
    curl_close($ch);

    $ip_data = json_decode($ip_data_in, true);
    $ip_data = str_replace('&quot;', '"', $ip_data);

    if($ip_data && $ip_data['geoplugin_countryName'] != null) {
        $country = $ip_data['geoplugin_countryName'];
    }

    return $country;
}

// Get visitor details
$ip_address = $_SERVER['REMOTE_ADDR'];
$page_visited = $_SERVER['REQUEST_URI'];
$referral_source = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : "Direct";
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$country = ip_visitor_country();
function get_browser_info($user_agent) {
    $browser_info = 'Unknown';
    
    $browser_patterns = array(
        'Firefox' => 'Firefox',
        'Chrome' => 'Chrome',
        'Safari' => 'Safari',
        'Opera' => 'Opera',
        'MSIE' => 'Internet Explorer',
        'Trident' => 'Internet Explorer'
    );
    
    foreach ($browser_patterns as $key => $value) {
        if (strpos($user_agent, $key) !== false) {
            $browser_info = $value;
            break;
        }
    }
    
    return $browser_info;
}

$browser = get_browser_info($user_agent);

function getOS($user_agent) {
    $os_platform = "Unknown";
    $os_array = array(
        '/windows nt 10/i'      => 'Windows 10',
        '/windows nt 6.3/i'     => 'Windows 8.1',
        '/windows nt 6.2/i'     => 'Windows 8',
        '/windows nt 6.1/i'     => 'Windows 7',
        '/windows nt 6.0/i'     => 'Windows Vista',
        '/windows nt 5.2/i'     => 'Windows Server 2003/XP x64',
        '/windows nt 5.1/i'     => 'Windows XP',
        '/windows xp/i'         => 'Windows XP',
        '/windows nt 5.0/i'     => 'Windows 2000',
        '/windows me/i'         => 'Windows ME',
        '/win98/i'              => 'Windows 98',
        '/win95/i'              => 'Windows 95',
        '/win16/i'              => 'Windows 3.11',
        '/macintosh|mac os x/i' => 'Mac OS X',
        '/mac_powerpc/i'        => 'Mac OS 9',
        '/linux/i'              => 'Linux',
        '/ubuntu/i'             => 'Ubuntu',
        '/iphone/i'             => 'iPhone',
        '/ipod/i'               => 'iPod',
        '/ipad/i'               => 'iPad',
        '/android/i'            => 'Android',
        '/blackberry/i'         => 'BlackBerry',
        '/webos/i'              => 'Mobile'
    );

    foreach ($os_array as $regex => $value) {
        if (preg_match($regex, $user_agent)) {
            $os_platform = $value;
        }
    }

    return $os_platform;
}

// Get visitor details
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$operating_system = getOS($user_agent);

// Output the operating system


// Prepare and execute the SQL query using prepared statements to prevent SQL injection
$sql = "INSERT INTO analytics(ip_address, page_visited, referral_source, user_agent, country,browser , operating_system) 
        VALUES (?, ?, ?, ?, ?, ?,?)";
$stmt = $conn->prepare($sql);

// Bind parameters
if ($stmt) {
    // Bind parameters
    $stmt->bind_param("sssssss", $ip_address, $page_visited, $referral_source, $user_agent, $country, $browser, $operating_system);
    
    // Execute the statement
    if ($stmt->execute()) {
        echo "Tracking information saved successfully.\n";
    } else {
        echo "Error: " . $stmt->error; // Print error message if query execution fails
    }
} else {
    echo "Error: Failed to prepare statement."; // Print error message if statement preparation fails
}

// Close the statement
$stmt->close();

// Close the database connection
$conn->close();

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <title>Document</title> -->
    <link rel="shortcut icon" href="img/U.png" type="image/x-icon">
    <script src="https://kit.fontawesome.com/f2160b4ca1.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        /* body {
            position: sticky;
        } */
        body, html {
            height: 100%;
            margin: 0;
            padding: 0;
            overflow: auto;
        }


        .topbar {
            background-color: #23242a;
            /* position: sticky; */
            /* top: 0; */
            z-index: 1000;
            /* Ensure it appears above other content */
        }

        .sidebar {
            max-width: 25%;
            font-size: 20px;
            position: sticky;
            top: 0;
            float: left;
            height: 100vh;
            overflow-y: auto;
            z-index: 1000;
            /* Ensure it appears above other content */
        }
        /* .sidebar{
            max-width: 25%;
            font-size: 20px;
            position: sticky;
            float: left;
        } */

        .sidebar::after {
            content: "";
            clear: both;
            display: table;
        }

        .sidebar ul {
            min-height: 550px;
            background-color: #23242a;
            display: flex;
            flex-direction: column;
            list-style: none;
            text-align: left;
            height: 100%;
            padding-right: 10px;
            justify-content: space-between;
            padding-bottom: 20px;
            padding-top: 20px;
        }

        .sidebar ul li i {
            padding-right: 10px;
        }

        .sidebar ul li:hover {
            border: 2px solid white;
            padding-top: 5px;
            padding-bottom: 5px;
        }

        .sidebar ul li {
            padding-left: 10px;
            text-decoration: none;
        }

        .sidebar ul li a {
            text-decoration: none;
            color: white;
        }

        /* ##################################### */
        .topbar::after {
            content: "";
            clear: both;
            display: table;
        }

        .topbar ul {
            /* min-height: 550px; */
            background-color: #23242a;
            display: flex;
            /* flex-direction: column; */
            list-style: none;
            text-align: left;
            height: 100%;
            padding-right: 10px;
            justify-content: left;
            padding-bottom: 17px;
            padding-top: 17px;
        }

        .topbar ul li i {
            padding-right: 30px;
            padding-left: 30px;
            font-size: 21px;
        }

        /* .topbar ul li:hover {
            border: 2px solid white;
            padding-top: 5px;
            padding-bottom: 5px;
        } */

        .topbar ul li {
            padding-left: 40px;
            text-decoration: none;
        }

        .topbar ul li a {
            text-decoration: none;
            color: white;
        }
    </style>
</head>

<body>
    <div class="topbar">
        <ul>
            <li><a href="/cms/index.php"><i class="fa-regular fa-user"></i></a></li>
            <li><a href="/frontend">View Site</a></li>
            <!-- <li><a href="#">Add New Site</a></li> -->
        </ul>
    </div>
    <div class="sidebar">
        <ul>
            <li><a href="index.php"><i class="fa fa-dashboard"></i>Dashboard</a></li>
            <li><a href="analytic.php"><i class="fa-solid fa-chart-line"></i>Analytics</a></li>
            <li><a href="post.php"><i class="fa-solid fa-file-lines"></i>Posts</a></li>
            <li><a href="page.php"><i class="fa-regular fa-file-lines"></i>Pages</a></li>
            <li><a href="comment.php"><i class="fa-regular fa-message"></i>Comments</a></li>
            <li><a href="user.php"><i class="fa-solid fa-user"></i>Users</a></li>
            <li><a href="setting.php"><i class="fa fa-gear"></i>Setting</a></li>
            <li><a href="logout.php"><i class="fa fa-sign-out"></i>Log Out</a></li>
        </ul>
    </div>
</body>

</html>
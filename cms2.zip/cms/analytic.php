<?php
include 'database.php';
include 'sidebar.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .head{
            float: left;
            margin-left: 30px;
            margin-top: 20px;
        }
        .analytic{
            display: flex;
            margin-left: 30px;
            margin-top: 20px;
            width: 83%;
            float: left;
            justify-content: space-around;
            
        }

        .country{
            margin-top: 30px;

            width: 87%;
            float: right;
            justify-content: space-around;
            border: 2px solid black;
            padding-top: 30px;
            font-size: 40px;
            position: relative;
        }
        .country span{
            display: flex;
            font-size: 40px;
            flex-direction: column;
            padding-top: 10px;
            justify-content: center;
            align-items: center;
            list-style: none;
            min-height: 40vh;
        }
        .analytic div{
            border: 2px solid black;
            width: 33%;
            padding-top: 30px;
            height: 300px;
            display: flex;
            flex-direction: column;
            text-align: center;
            font-size: 30px;
            /* position: absolute; */
        }
        .analytic div span{
            display: block;
            font-size: 50px;
            padding-top: 80px;
            position: relative;
        }
    </style>
</head>
<body>
    <?php
    $sql = "SELECT * FROM analytics";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $page_visits_count = 0;
        $total_visits = $result->num_rows;
        $top_countries = array();
        while ($row = $result->fetch_assoc()) {
            $page_visits_count++;
            $country = $row["country"];
            if (isset($top_countries[$country])) {
                $top_countries[$country]++;
            } else {
                $top_countries[$country] = 1;
            }
        }
        arsort($top_countries);
        $top_three_countries = array_slice($top_countries, 1, 4, true);
    } else {
        echo "No analytics data available";
    }
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
        $page = $row["page_visited"];
        $country = $row["country"];
        }
    } else {
        echo "No analytics data available";
    }
    $sql_page_visits_count = "SELECT COUNT(DISTINCT page_visited) AS page_visits_count FROM analytics";
    $result_page_visits_count = $conn->query($sql_page_visits_count);
    $row_page_visits_count = $result_page_visits_count->fetch_assoc();
    $page_visits_count = $row_page_visits_count['page_visits_count'];

    // Close the database connection
    
    $sql_total_visits = "SELECT COUNT(id) AS total_visits FROM analytics";
    $result_total_visits = $conn->query($sql_total_visits);
    $row_total_visits = $result_total_visits->fetch_assoc();
    $total_visits = $row_total_visits['total_visits'];
    
    // ##################country#####################
    $sql_top_three_countries = "SELECT country, COUNT(*) AS visit_count FROM analytics GROUP BY country ORDER BY visit_count DESC LIMIT 3";
            $result_top_three_countries = $conn->query($sql_top_three_countries);

            if ($result_top_three_countries->num_rows > 0) {
            echo "<ul>";
            while($row = $result_top_three_countries->fetch_assoc()) {
            $country = $row["country"];
                $Visit_Count = $row["visit_count"];}}
                $selectedDate = date('Y-m-d');
$sql = "SELECT COUNT(*) AS traffic FROM analytics WHERE DATE(timestamp) = '$selectedDate'";
$result = $conn->query($sql);
if (!$result) {
    die("Query failed: " . $conn->error);
}if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $traffic_day = $row['traffic'];}?>
    <h1 class="head">Analytics</h1>
    <div class="analytic">
    <div class="">Total Posts: <span><?php $sql = "SELECT COUNT(*) AS post_count FROM post"; $result = $conn->query($sql);if ($result) {$row = $result->fetch_assoc();
        $post_count = $row['post_count'];} else {
        $post_count = 0;}echo $post_count;?></span></div>
    <div class="" style="font-size: 25px;">Overall Views: <Span><?php echo $total_visits; ?></Span></div>
    <div class="" style="font-size: 25px;">Visiter This Month: <span style="padding-top: 47px;"><?php $sql = "SELECT YEAR(timestamp) AS year, MONTH(timestamp) AS month, COUNT(*) AS traffic FROM analytics GROUP BY YEAR(timestamp), MONTH(timestamp) ORDER BY year DESC, month DESC";
        $result = $conn->query($sql); $trafficByMonth = array(); if (!$result) {die("Query failed: " . $conn->error);}
        if ($result->num_rows > 0) {while ($row = $result->fetch_assoc()) {$year = $row['year']; $month = $row['month']; $traffic = $row['traffic']; $trafficByMonth["$year-$month"] = $traffic; echo $traffic;}}?></span></div>
    <div class="">Page Visits: <span><?php echo $page_visits_count; ?></span></div>
    <div class="">Today View: <span><?php echo $traffic_day;?></span></div>
    </div>
    <div class="country">Top Countries Trafic: <span><?php foreach ($top_three_countries as $country => $visit_count) : ?>
    <li><?php echo $country . ": " . $visit_count; ?></li>
    <?php endforeach; ?></span>
    </div>
</body>
</html>
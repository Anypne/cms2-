<?php
$servername="localhost";
$username ="root";
$password="";
$DATABASE="cms";
$conn = mysqli_connect($servername, $username, $password,$DATABASE);
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
//   }
//   echo "Connected successfully";
if ($_SERVER["REQUEST_METHOD"] == "POST"){
    $user=$_POST['us'];
    $pass=$_POST['ps'];
    $query="SELECT * FROM `login` WHERE username = '$user' and password = '$pass'";
    $result = mysqli_query($conn,$query);
    $count= mysqli_num_rows($result);
    if ($count>0){
        header("Location: index.php");
        exit();
    }else{
        echo '<script>alert("User Not Found")</script>';
    }

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/1.jpg" type="image/x-icon">
    <title>Login-Account</title>
    <script>
        history.pushState(null, null, location.href);
        window.onpopstate = function () {
            history.go(0);
        };
    </script>
    <script>
if ( window.history.replaceState ) {
  window.history.replaceState( null, null, window.location.href );
}
</script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins&display=swap');
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        body{
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: #23242a;
        }
        .box{
            position: relative;
            width: 380px;
            height: 420px;
            border-radius: 8px;
            background-color: #1c1c1c;
            overflow: hidden;
        }
        .box::before{
            content: "";
            position: absolute;
            top: -50;
            left: -50;
            width: 380px;
            height: 420px;
            background: linear-gradient(0deg,transparent,transparent,#45f3ff,#45f3ff,#45f3ff);
            z-index: 1;
            transform-origin: bottom right;
            animation: animate 6s linear infinite;
        }
        .box::after{
            content: "";
            position: absolute;
            top: -50;
            left: -50;
            width: 380px;
            height: 420px;
            background: linear-gradient(0deg,transparent,transparent,#45f3ff,#45f3ff,#45f3ff);
            z-index: 1;
            transform-origin: bottom right;
            animation: animate 6s linear infinite;
            animation-delay: -3s;
        }
        .borderline{
            position: absolute;
            top: 0;
            inset: 0;
        }
        .borderline::before{
            content: "";
            position: absolute;
            top: -50;
            left: -50;
            width: 380px;
            height: 420px;
            background: linear-gradient(0deg,transparent,transparent,#ff2770,#ff2770,#ff2770);
            z-index: 1;
            transform-origin: bottom right;
            animation: animate 6s linear infinite;
            animation-delay: 1.5s;

        
        }
        .borderline::after{
            content: "";
            position: absolute;
            top: -50;
            left: -50;
            width: 380px;
            height: 420px;
            background: linear-gradient(0deg,transparent,transparent,#ff2770,#ff2770,#ff2770);
            z-index: 1;
            transform-origin: bottom right;
            animation: animate 6s linear infinite;
            animation-delay: 4.5s;        
        }
        @keyframes animate{

            0%{transform: rotate(0deg);}
            100%{transform: rotate(360deg);}
        }
        .box form{
            position: absolute;
            inset: 4px;
            background-color: #222;
            padding: 50px 40px;
            border-radius: 8px;
            z-index: 2;
            display: flex;
            flex-direction: column;
        }
        .box form h2{
            color: #fff;
            font-weight: 500;
            text-align: center;
            letter-spacing: 0.1em;
        }
        .box form .inputbox{
            position: relative;
            width: 300px;
            margin-top: 35px;
        }
        .box form .inputbox input{
            position: relative;
            width: 100%;
            padding: 20px 10px 10px;
            background: transparent;
            outline: none;
            box-shadow: none;
            border: none;
            color: #edeef5;
            font: 1em;
            letter-spacing: 0.05em;
            transition: 0.5s;
            z-index: 10;
        }
        .box form .inputbox span{
            position: absolute;
            left: 0;
            padding: 20px 0px 10px;
            pointer-events: none;
            font-size: 1em;
            color: #8f8f8f;
        }
        .box form .inputbox input:valid ~ span,.box form .inputbox input:focus ~ span{
            color: #fff;
            font-size: 0.75em;
            transform: translateY(-34px);

        }
        .box form .inputbox i{
            position: absolute;
            left: 0;
            bottom: 0;
            width: 100%;
            height: 2px;
            background: #fff;
            border-radius: 4px;
            overflow: hidden;
            pointer-events: none;
            transition: 0.5s;
        }
        .box form .inputbox input:valid ~ i,.box form .inputbox input:focus ~ i{
            height: 44px;
        }
        .links{
            text-align: center;
        }
        .links a{
            margin: 10px 0;
            font-size: 00.75em;
            color: #8f8f8f;
            text-decoration: none;
        }
        .links a:hover{
            color: #fff;
        }
        .box input[type="submit"]{
            border: none;
            outline: none;
            padding: 9px 25px;
            background: #fff;
            cursor: pointer;
            font-size: 0.9em;
            border-radius: 4px;
            font-weight: 600;
            width: 100%;
            margin-top: 10px;
        }
        .box input[type="submit"]:active{
            opacity: 0.8;
        }
    </style>
</head>

<body>
    <div class="box">
        <span class="borderline"></span>
        <form action="" method="post">
            <h2>Sign-In</h2>
            <div class="inputbox"><input type="text" name="us" id="" required>
                <span>UserName</span>
            </div>
            <div class="inputbox"><input type="password" name="ps" id="" required>
                <span>PassWord</span>
            </div>
            <i></i>
            <div class="links">
                <a href="#">Forget Password</a>
            </div>
            <input type="submit" value="Login">
        </form>
    </div>
</body>

</html>
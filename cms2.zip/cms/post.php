<?php
include 'sidebar.php';
include 'database.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Posts</title>
    <style>
        h2 {
            float: left;
            margin-left: 35px;
            font-size: 35px;
            margin-top: 10px;
        }
        .posts{
            border: 1px solid black;
            margin-top: 10px;
            width: 80%;
            float: right;
            margin-right: 35px;
            /* clear: both; */
        }
        .posts:hover{box-shadow: 4px 4px rgb(113, 112, 112);
        }
        .posts img{
            float: left;
            /* height: 30px; */
            width: 15%;
            height: 120px;
            object-fit: cover;


            
            /* clear: both; */
        }
        .posts .postaria{
            float: left;
            padding-top: 15px;
            
            width: 60%;
            padding: 15px;
        }
        
        .postaria p{
            font-size: 14px;
            padding-top: 5px;
        }
        .posts .actions{
            text-align: center;
            text-decoration: none;
            margin-top: 16px;
            color: black;
            display: flex;
            width: 25%;
            justify-content: space-evenly;
            float: left;
            /* border: 2px solid black; */
            /* flex-direction: column; */
            min-height: 10vh;
            align-items: center;
        }
        .posts .actions a{
            text-decoration: none;
            color: black;
        }
        .time{
            font-size: 13px;
            padding-top: 20px;
            float: right;
            padding-right: 30px;
            /* display: flex; */
            /* align-items: center; */

        }
        .add{
            border: 1px solid black;
            background-color: #23242a;
            color: white;
            /* display: flex; */
            margin-left: 50px;
            font-size: 30px;
            width: 20%;
            float: left;
            margin-top: 10px;
            text-align: center;
        }

        .add a{
            text-decoration: none;
            color: white;
        }
    </style>
</head>

<body>
    <?php
    $sql = "SELECT COUNT(*) AS post_count FROM post";
    $result = $conn->query($sql);
    if ($result) {$row = $result->fetch_assoc();
        $post_count = $row['post_count'];} else {
        $post_count = 0;}
    if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['del'])) {
        $id = $_GET['del'];
        $delete = mysqli_query($conn, "DELETE FROM `post` WHERE `Sr#`='$id'");
    }
        $sql="SELECT * FROM `post` ORDER BY `Sr#` DESC";
        $result =$conn->query($sql);
        echo"<h2>Post ($post_count)</h2>";
        echo'<div class="add"><a href="postpage.php">Add Post</a></div>';
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                $truncated_text = substr($row['title'], 0, 70);
                $truncated_text_2 = substr($row['content'], 0, 300);
                $img1 = $row["img1"];
                if (!empty($row['img1'])) {
                    $img_src = './img/' . $row["img1"];
                    $img_html = '<img src="' . $img_src . '" alt="" srcset="">';
                } else {
                    // If image field is empty, display alternative content or leave it blank
                    $img_html = '<img src="img/user.png" alt="" srcset="">'; // You can set some default image or leave it blank
                }
        

        // echo $truncated_text . "<br>";
                echo'<div class="posts">
                '.$img_html.'
                <div class="postaria">
                    <h5>'.$truncated_text.'</h5>
                    <p>'.$truncated_text_2.'</p>
                </div>
                <div class="actions"><a href="?del=' . $row["Sr#"] . '" class="fa-solid fa-trash"></a><a href="" class="fa-solid fa-eye"></a><a href="postpage.php?modi='.$row["Sr#"].'" class="fa-solid fa-file-pen"></a></div>
                <div class="time" id="current-time">Upload Time:'.$row["date"].'</div>
                
            </div>';
            }}
    ?>
    
</body>

</html>
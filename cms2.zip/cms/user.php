<?php
include 'sidebar.php';
include 'database.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>
    <style>
        h1{
            margin-top: 10px;
            margin-left: 15px;
            float: left;
            font-size: 50px;
        }
        table {
            border-collapse: collapse;
            width: 80%;
            float: left;
            margin-top: 30px;
            margin-left: 30px;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        .actions{
            /* display: flex; */
            /* justify-content: space-evenly; */
            /* flex-grow: row; */
            /* text-align: center; */
        }
        .actions a{
            color: black;
            letter-spacing: 20px;
            text-decoration: none;
            /* font-size: 20px; */
        }
    </style>
</head>
<body>
    <h1>Users</h1>
<?php
 if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['del'])) {
    $id = $_GET['del'];
    $delete = mysqli_query($conn, "DELETE FROM `login` WHERE `Sr#`='$id'");
}
if (isset($_GET['modi'])) {
    $id = $_GET['modi'];
    echo '<script></script>';
}
$sql="SELECT * FROM `login`";
$result =$conn->query($sql);
if ($result->num_rows > 0) {

    echo'<table><tr>
    <th>Username</th>
    <th>Password</th>
    <th>Date</th>
    <th>Actions</th>
</tr>';
    // output data of each row
    while($row = $result->fetch_assoc()) {
echo'

<tr>
    <td>'.$row["username"].'</td>
    <td>'.$row["password"].'</td>
    <td>'.$row["date"].'</td>
    <td class="actions"><a href="?del=' . $row["Sr#"] . '" class="fa-solid fa-trash"></a><a href="?modi=' . $row["Sr#"] . '" class="fa-solid fa-file-pen"></a></td>
    </tr>';}
echo'</table>';
}?>
</div>
</body>
</html>
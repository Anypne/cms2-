<?php
include 'sidebar.php';
include 'database.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>Comments</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        h1 {
            float: left;
            margin-top: 20px;
            margin-left: 35px;
        }

        .comment {
            font-size: 20px;
            width: 80%;
            margin-top: 20px;
            margin-right: 35px;
            /* background-color: #fafafa; */
            border: 1px solid rgb(117, 115, 115);
            border-radius: 2px;
            float: right;
        }

        .comment:hover {
            box-shadow: 4px 4px rgb(113, 112, 112);
        }

        .comment .imgaria {
            width: 15%;
            /* border: 2px solid black; */
        }

        .comment img {
            float: left;
            width: 130px;
        }

        .commentdata {
            float: left;
            width: 70%;
            padding-top: 20px;
            /* flex-direction: column; */
            height: 100%;
        }

        .comment .del {
            /* float: left; */
            width: 15;
            padding-top: 20px;
            display: flex;
            justify-content: space-around;
        }

        .commentdata p {
            font-size: 13px;
            overflow: hidden;
        }

        .comment .del a {
            text-decoration: none;
            color: black;
            cursor: pointer;

        }
    </style>
</head>

<body>
    <?php
    $sql = "SELECT COUNT(*) AS post_count FROM comments"; $result = $conn->query($sql);if ($result) {$row = $result->fetch_assoc();
        $post_count = $row['post_count'];} else {
        $post_count = 0;}

    if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['del'])) {
        $id = $_GET['del'];
        $delete = mysqli_query($conn, "DELETE FROM `comments` WHERE `Sr#`='$id'");
    }
    
      
    $sql = "SELECT * FROM comments";
    $result = $conn->query($sql);
    echo" <h1>Comments ($post_count)</h1>";
    
    if ($result->num_rows > 0) {
      // output data of each row
      while($row = $result->fetch_assoc()) {
        // echo "id: " . $row["Sr#"]. " - Name: " . $row["Email"]. " " . $row["comment"]. "<br>";
        echo '<div class="comment">
        <div class="imgaria">
        <img src="img/user.png" alt="" srcset=""></div>
        <div class="commentdata">
            <h5>' .$row["Email"].'</h5>
            <p>'.$row["comment"].'</p>
        </div>
            <div class="del"><a href="?del=' . $row["Sr#"] . '" class="fa-solid fa-trash"></a><a href="#" class="fa-solid fa-reply"></a></div>
    </div>';
}} else {
      echo "0 results";}
    $conn->close();
    ?>
</body>

</html>
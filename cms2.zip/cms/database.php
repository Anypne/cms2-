<?php
$servername="localhost";
$username ="root";
$password="";
$DATABASE="cms";
$conn = mysqli_connect($servername, $username, $password,$DATABASE);
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
//   }
//   echo "Connected successfully";
?>
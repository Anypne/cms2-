<?php
include 'database.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Page</title>
    <script src="https://cdn.ckeditor.com/ckeditor5/41.1.0/classic/ckeditor.js"></script>
    <script>
        // Function to clear form data after submission
        function clearForm() {
            document.getElementById("pos").reset();
        }
    </script>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins&display=swap');
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        body{
            /* display: flex; */
            /* justify-content: center; */
            /* align-items: center; */
            /* min-height: 100vh; */
            /* background-color: #23242a; */
        }
        label{
            display: block;
            margin-top: 30px;
            margin-left: 35px;
            font-size: 30px;
        }
        #title{
            width: 95%;
            border: none;
            margin-top: 50px;
            margin-left: 35px;
            border-bottom: 1px solid black;
            font-size: 20px;
        }
        .editor{
            width: 95%;
            margin-top: 30px;
            margin-left: 35px;
            /* min-height: 400px;  */
            /* resize: none; Allow vertical resizing only */
            overflow-y: hidden; 
            display: block;
        }
        input:focus {
            outline: none;
        }
        .bar{
            background-color: #23242a;
            color: white;
            width: 100%;
            justify-content: center;
            display: flex;
            align-items: center;
            height: 50px;
        }
        .pos{
            width: 100%;
            /* border: 2px solid black; */
            margin-top: 20px;
            /* display: flex; */
        }
        .label{
            width: 50%;
            height: 60px;
            margin-top: 30px;
            font-size: 30px;
            margin-left: 35px;
        }
        .btn{
            width: 20%;
            height: 60px;
            margin-top: 30px;
            background-color: #23242a;
            color: white;
            font-size: 30px;
            display: block;
            margin-left: 35px;
        }
    </style>
</head>
<body>
    <?php
    if (isset($_GET['modi'])) {
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
            $id = $_POST['id'];
            $title = $_POST['title'];
            $content = $_POST['description'];
            $label = $_POST['label'];
            
            // Assuming $conn is your database connection
            
            // Sanitize input (to prevent SQL injection)
            $title = mysqli_real_escape_string($conn, $title);
            $content = mysqli_real_escape_string($conn, $content);
            $label = mysqli_real_escape_string($conn, $label);
            
            $sql = "UPDATE `pages` SET `title`='$title', `description`='$content', `label`='$label' WHERE `Sr#`='$id'";
            
            if ($conn->query($sql) === TRUE) {
                echo '<script>alert("Page Is Uploaded Successfully")</script>';
            header("Location: page.php");
            exit();
            } else {
                echo "Error updating post: " . $conn->error;
            }
        }
    
       if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['modi'])) {
        $id = $_GET['modi'];
        $sql = "SELECT * FROM `pages` WHERE `Sr#`='$id'";
        $result = $conn->query($sql);
        // Assuming $title, $content, and $label are obtained from a safe source
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc(); // Fetch the row from the query result
            // Assuming $title, $content, and $label are obtained from a safe source
            $title = htmlspecialchars($row['title']);
            $content = htmlspecialchars($row['description']);
            // echo $id;
            echo '
            <div class="bar">Edit Your Post</div>
            <form action="" method="POST" class="pos" id="pos" enctype="multipart/form-data">
            <div class="img">
            <label for="image">Image 1
            <input type="file" name="img1" id=""></label>
            <label for="image">Image 2
            <input type="file" name="img2" id=""></label>
        </div>
                <input type="hidden" name="id" value="' . $id . '">
                <input type="text" name="title" id="title" value="' . $title . '">
                <div class="editor">
                    <textarea name="content" id="editor" class="editor" placeholder="Type Your Content">' . $content . '</textarea>
                </div>
                <input type="submit" value="Update" class="btn">                    
            </form>
            ';
        }}
    }
   else{
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get form input values
        $title = $_POST['title'];
        $content = $_POST['content'];
        $img1 = ($_FILES["img1"]["name"]);
        $img2 = ($_FILES["img2"]["name"]);
         $tempname = $_FILES['img1']['tmp_name'];
         $tempname2 = $_FILES['img2']['tmp_name'];
        $folder = "img/page" . $img1;
        $folder2 = "img/page" . $img2;
        move_uploaded_file($tempname, $folder);
        move_uploaded_file($tempname2, $folder2);
        move_uploaded_file($tempname3, $folder3);
        // Insert data into the database
        $sql = "INSERT INTO `pages`(`title`, `description`,`img1`,`img2`) VALUES ('$title', '$content','$img1',$img2)";
        $result = $conn->query($sql);
    
        // Check if the query was successful
        if ($result) {
            echo '<script>alert("Page Is Uploaded Successfully")</script>';
            header("Location: page.php");
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    echo'<div class="bar">Edit Your Page</div>
    <form action="" method="post" class="pos" id="pos" enctype="multipart/form-data">
        <div class="img">
                <label for="image">Image 1
                <input type="file" name="img1" id=""></label>
                <label for="image">Image 2
                <input type="file" name="img2" id=""></label>
            </div>
        <input type="text" name="title" id="title" placeholder="Type Your Title">
        <div class="editor">
        <textarea name="content" id="editor" class="editor" placeholder="Type Your Content"></textarea></div>
        <input type="submit" value="Publish" class="btn">';
   }
    ?>
    
                <script>
                        ClassicEditor
                                .create( document.querySelector( '#editor' ) )
                                .then( editor => {
                                        console.log( editor );
                                } )
                                .catch( error => {
                                        console.error( error );
                                } );
                </script>
</div>
    </form>
</body>
</html>
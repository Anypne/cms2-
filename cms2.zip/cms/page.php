<?php
include 'sidebar.php';
include 'database.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pages</title>
    <style>
        h2 {
            float: left;
            margin-left: 35px;
            font-size: 35px;
            margin-top: 10px;
        }
        .posts{
            float: right;
            margin-right: 35px;
            border: 1px solid black;
            margin-top: 10px;
            width: 80%;
            /* float: left; */
            margin-left: 35px;
        }
        .posts:hover{box-shadow: 4px 4px rgb(113, 112, 112);
        }
        .posts img{
            float: left;
            /* height: 30px; */
            width: 15%;
            
            /* clear: both; */
        }
        .posts .postaria{
            float: left;
            padding-top: 15px;
            
            width: 60%;
            padding: 15px;
        }
        .postaria p{
            font-size: 14px;
            padding-top: 5px;
        }
        .posts .actions{
            text-align: center;
            text-decoration: none;
            margin-top: 16px;
            color: black;
            display: flex;
            width: 25%;
            justify-content: space-evenly;
            float: left;
            /* border: 2px solid black; */
            /* flex-direction: column; */
            min-height: 10vh;
            align-items: center;
        }
        .posts .actions a{
            text-decoration: none;
            color: black;
        }
        .time{
            font-size: 13px;
            padding-top: 20px;
            float: right;
            padding-right: 30px;
            /* display: flex; */
            /* align-items: center; */

        }
        .add{
            border: 1px solid black;
            background-color: #23242a;
            color: white;
            /* display: flex; */
            margin-left: 50px;
            font-size: 30px;
            width: 20%;
            float: left;
            margin-top: 10px;
            text-align: center;
        }

        .add a{
            text-decoration: none;
            color: white;
        }
    </style>
</head>

<body>
    <?php
    $sql = "SELECT COUNT(*) AS post_count FROM pages"; $result = $conn->query($sql);if ($result) {$row = $result->fetch_assoc();
        $post_count = $row['post_count'];} else {
        $post_count = 0;}
    if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['del'])) {
        $id = $_GET['del'];
        $delete = mysqli_query($conn, "DELETE FROM `pages` WHERE `Sr#`='$id'");
    }
    if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['modi'])) {
        $id = $_GET['modi'];
        $sql = "SELECT * FROM `pages` WHERE `Sr#`='$id'";
    $result = $conn->query($sql);
    }
        $sql="SELECT * FROM `pages`";
        $result =$conn->query($sql);
        echo"<h2>Pages ($post_count)</h2>";
        echo'<div class="add"><a href="newpage.php">Add Page</a></div>';
        if ($result->num_rows > 0) {
            // output data of each row
            while($row = $result->fetch_assoc()) {
                if (!empty($row['img1'])) {
                    $img_src = './img/' . $row["img1"];
                    $img_html = '<img src="' . $img_src . '" alt="" srcset="">';
                } else {
                    // If image field is empty, display alternative content or leave it blank
                    $img_html = '<img src="img/user.png" alt="" srcset="">'; // You can set some default image or leave it blank
                }
        // echo $truncated_text . "<br>";
                echo'<div class="posts">
                '.$img_html.'
                <div class="postaria">
                    <h5>'.$row['title'].'</h5>
                    <p>'.$row['description'].'</p>
                </div>
                <div class="actions"><a href="?del=' . $row["Sr#"] . '" class="fa-solid fa-trash"></a><a href="" class="fa-solid fa-eye"></a><a href="newpage.php?modi='.$row["Sr#"].'" class="fa-solid fa-file-pen"></a></div>
                </div>';
            }}
    ?>
</body>

</html>
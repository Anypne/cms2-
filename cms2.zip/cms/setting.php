<?php
include 'sidebar.php';
include 'database.php';
define('WP_SITEURL','/cms.com');
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the form submission is for changing title
    if (isset($_POST["change_title"])) {
        // Get the title from the form
        $title = $_POST["title"];

        // Prepare an SQL statement to update the title
        $sql = "UPDATE `site` SET `sitetitle` = '$title' WHERE `Sr#` = 0";

        // Bind parameters to the prepared statement

        // Execute the prepared statement
        if ($conn->query($sql) === TRUE){
            echo '<script>alert("Title Is Uploaded Successfully")</script>';
            header("Location: setting.php");
            exit();
        } else {
            header("Location: setting.php");
            exit();
        }

        // Close the statement
        $stmt->close();
    }

    // Check if the form submission is for changing description
    if (isset($_POST["change_description"])) {
        // Get the description from the form
        $description = $_POST["description"];

        // Prepare an SQL statement to update the description
        $sql = "UPDATE `site` SET `sitedescription` = '$description' WHERE `Sr#` = 0";

        // Bind parameters to the prepared statement

        // Execute the prepared statement
        if ($conn->query($sql) === TRUE){
            echo '<script>alert("Description Is Uploaded Successfully")</script>';
            header("Location: setting.php");
            exit();
        } else {
            header("Location: setting.php");
            exit();
        }

        // Close the statement
        $stmt->close();
    }
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setting</title>

<style>
    .settings,.settings2{
        width: 80%;
        /* border: 2px solid red; */
        float: left;
        margin-left: 35px;
        margin-top: 20px;
    }
    .data{
        margin-top: 15px;
        margin-left: 35px;
        /* border: 1px solid black; */
        
    }
    .data h2,h4{
        display: inline;
        justify-content: center;
    }
    .data h4{
        margin-left: 50px;
        width: 60%;
        border: none;
        outline: none;
        border-bottom: 2px solid black;
    }
    .data input{
        margin-left: 50px;
        width: 30%;
        border: none;
        outline: none;
        text-align: center;
        font-size: 20px;
        font: bold;
        border-bottom: 2px solid black;
    }
    .data button{
        color: white;
        background-color: #23242a;
        padding: 10px 20px 10px 20px;
    }
    textarea{
        width: 100%;
        height: 120px;
        padding: 12px 20px;
        box-sizing: border-box;
        border: 2px solid #dedddd;
        border-radius: 4px;
        background-color: #f8f8f8;
        font-size: 16px;
        resize: none;
    }
</style>
</head>
<body>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
    <div class="settings">
        <h1>Setting</h1>
        <div class="data">
            <h2>Database:</h2>
            <h4><?php echo "$DATABASE";?></h4>
            
        </div>
        <?php
        
            $sql="SELECT * FROM `site`";
            $result =$conn->query($sql);
            if ($result->num_rows > 0) {
                // output data of each row
                while($row = $result->fetch_assoc()) {
                    $sitetitle= $row['sitetitle'];
                    $sitedescription= $row['sitedescription'];
                
            echo'<div class="data">
            <h2>Title:</h2>
            <input type="text" id="" name="title" value="'.$sitetitle.'">
            <button type="submit" name="change_title">Change</button>
        </div>
        <div class="data">
            <h2>Description:</h2>
            <textarea type="text" id="" name="description">'.$sitedescription.'</textarea>
            <button type="submit" name="change_description">Change</button>
        </div>';  
    }}  

        ?>
        
    </div>
</form>
    <div class="settings2">
        <h1>Crawlers and indexing</h1>
        <div class="data">
            <h2>Sitemap:</h2>
            <h4>www.jobs-kr.com/sitemap.xml</h4>
            
        </div>
    </div>
</body>
</html>
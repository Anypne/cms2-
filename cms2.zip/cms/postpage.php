<?php
include 'database.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Post</title>
    <script src="https://cdn.ckeditor.com/ckeditor5/41.1.0/classic/ckeditor.js"></script>
    <script>
        // Function to clear form data after submission
        function clearForm() {
            document.getElementById("pos").reset();
        }
    </script>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins&display=swap');
        *{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }
        body{
            /* display: flex; */
            /* justify-content: center; */
            /* align-items: center; */
            /* min-height: 100vh; */
            /* background-color: #23242a; */
        }
        #title{
            width: 95%;
            border: none;
            margin-top: 50px;
            margin-left: 35px;
            border-bottom: 1px solid black;
            font-size: 20px;
        }
        .editor{
            width: 95%;
            margin-top: 30px;
            margin-left: 35px;
            /* min-height: 400px;  */
            /* resize: none; Allow vertical resizing only */
            overflow-y: hidden; 
            display: block;
        }
        input:focus {
            outline: none;
        }
        .bar{
            background-color: #23242a;
            color: white;
            width: 100%;
            justify-content: center;
            display: flex;
            align-items: center;
            height: 50px;
        }
        .pos{
            width: 100%;
            /* border: 2px solid black; */
            margin-top: 20px;
            /* display: flex; */
        }
        .label{
            width: 50%;
            height: 60px;
            margin-top: 30px;
            font-size: 30px;
            margin-left: 35px;
        }
        .btn{
            width: 20%;
            height: 60px;
            margin-top: 30px;
            background-color: #23242a;
            color: white;
            font-size: 30px;
            display: block;
            margin-left: 35px;
        }
        .img{
            display: flex;
            margin-left: 35px;
        }
        label{
            display: block;
            margin-top: 30px;
            margin-left: 35px;
            font-size: 30px;
        }
        input[type=file]{
            /* margin-top: 20px;
            margin-left: 35px; */
        }
    </style>
</head>
<body>
    
    <?php
    if (isset($_GET['modi'])) {
        if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
            $id = $_POST['id'];
            $title = $_POST['title'];
            $content = $_POST['content'];
            $label = $_POST['label'];

            $img1 = ($_FILES["img1"]["name"]);
            $img2 = ($_FILES["img2"]["name"]);
            $img3 = ($_FILES["img3"]["name"]);
            $tempname = $_FILES['img1']['tmp_name'];
            $tempname2 = $_FILES['img2']['tmp_name'];
            $tempname3 = $_FILES['img3']['tmp_name'];
            $folder = "img/" . $img1;
            $folder2 = "img/" . $img2;
            $folder2 = "img/" . $img3;
            move_uploaded_file($tempname, $folder);
            move_uploaded_file($tempname2, $folder2);
            move_uploaded_file($tempname3, $folder3);
            
            // Assuming $conn is your database connection
            
            // Sanitize input (to prevent SQL injection)
            $title = mysqli_real_escape_string($conn, $title);
            $content = mysqli_real_escape_string($conn, $content);
            $label = mysqli_real_escape_string($conn, $label);
            
            $sql = "UPDATE `post` SET `title`='$title', `content`='$content', `label`='$label' , `img1`='$img1',`img2`='$img2' , `img3` = '$img3' WHERE `Sr#`='$id'";
            
            if ($conn->query($sql) === TRUE) {
                echo '<script>alert("Post Is Uploaded Successfully")</script>';
            header("Location: post.php");
            exit();
            } else {
                echo "Error updating post: " . $conn->error;
            }
        }
    
       if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['modi'])) {
        $id = $_GET['modi'];
        $sql = "SELECT * FROM `post` WHERE `Sr#`='$id'";
        $result = $conn->query($sql);
        // Assuming $title, $content, and $label are obtained from a safe source
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc(); // Fetch the row from the query result
            // Assuming $title, $content, and $label are obtained from a safe source
            $title = htmlspecialchars($row['title']);
            $content = htmlspecialchars($row['content']);
            $label = htmlspecialchars($row['label']);
            
            // echo $id;
            echo '
            <div class="bar">Edit Your Post</div>
            <form action="" method="POST" class="pos" id="pos" enctype="multipart/form-data">
            <div class="img">
            <label for="image">Image 1
            <input type="file" name="img1" id=""></label>
            <label for="image">Image 2
            <input type="file" name="img2" id=""></label>
            <label for="image">Image 3
            <input type="file" name="img3" id=""></label>
        </div>
                <input type="hidden" name="id" value="' . $id . '">
                <input type="text" name="title" id="title" value="' . $title . '">
                <div class="editor">
                    <textarea name="content" id="editor" class="editor" placeholder="Type Your Content">' . $content . '</textarea>
                </div>
                <input type="text" name="label" class="label" placeholder="Tags Here" value="' . $label . '">
                <input type="submit" value="Update" class="btn">                    
            </form>
            ';
        }}
    }
    else{
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
         // Get form input values
         $title = $_POST['title'];
         $content = $_POST['content'];
         $label = $_POST['label'];
        //  echo'<pre>';
        //  echo ($_FILES["img1"]["name"]);
        // echo'</pre>';
        $img1 = ($_FILES["img1"]["name"]);
        $img2 = ($_FILES["img2"]["name"]);
        $img3 = ($_FILES["img3"]["name"]);
         $tempname = $_FILES['img1']['tmp_name'];
         $tempname2 = $_FILES['img2']['tmp_name'];
         $tempname3 = $_FILES['img3']['tmp_name'];
        $folder = "img/" . $img1;
        $folder2 = "img/" . $img2;
        $folder2 = "img/" . $img3;
        move_uploaded_file($tempname, $folder);
        move_uploaded_file($tempname2, $folder2);
        move_uploaded_file($tempname3, $folder3);
        //  Insert data into the database
         $sql = "INSERT INTO `post`(`title`, `content`, `label`,`img1`,`img2`,`img3`) VALUES ('$title', '$content', '$label','$img1','$img2','$img3')";
         $result = $conn->query($sql);
        echo "$filename";
     
        //  Check if the query was successful
         if ($result) {
             echo '<script>alert("Post Is Uploaded Successfully")</script>';
             header("Location: post.php");
             exit();
         } else {
             echo "Error: " . $sql . "<br>" . $conn->error;
         }
     }
     echo'<div class="bar">Edit Your Post</div>
     <form action="" method="post" class="pos" id="pos" enctype="multipart/form-data">
        <div class="img">
            <label for="image">Image 1
            <input type="file" name="img1" id=""></label>
            <label for="image">Image 2
            <input type="file" name="img2" id=""></label>
            <label for="image">Image 3
            <input type="file" name="img3" id=""></label>
        </div>
         <input type="text" name="title" id="title" placeholder="Type Your Title">
         <div class="editor">
         <textarea name="content" id="editor" class="editor" placeholder="Type Your Content"></textarea></div>
         <input type="text" name="label" class="label" placeholder="Tags Here">     
         <input type="submit" value="Publish" class="btn">
     </div>
     </form>';
     }
     
    ?>
    <script>
                    ClassicEditor
                            .create( document.querySelector( '#editor' ) )
                            .then( editor => {
                                    console.log( editor );
                            } )
                            .catch( error => {
                                    console.error( error );
                            } );
    </script>
</body>
</html>